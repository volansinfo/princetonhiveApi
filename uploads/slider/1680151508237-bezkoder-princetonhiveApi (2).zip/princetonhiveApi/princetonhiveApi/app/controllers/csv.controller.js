const db = require("../models");
const User = db.user;
const generator = require("generate-password");
const fs = require("fs");
const csv = require("fast-csv");

const generateUUID = require("./uuid.controller");
const generateUuidStudent = require("./uuid.controller");
const { globalConfig, user } = require("../models");
const sendMail = require("./sendmail.controller");
const bcrypt = require("bcryptjs");
const { error, Console } = require("console");



async function generateStudentuuid() {
  const users = await User.findAll();
  // console.log(users)
  const studentUsers = users.filter((user) => {
    return user.uuid.slice(0, 3) == "STU";
  })
  // console.log(studentUsers, "ggh")

  const studentUuids = studentUsers.map((user) => {
    return parseInt(user.uuid.slice(-9))
  })
  console.log(studentUuids, "studentUuids")
  const maxNumber = Math.max(...studentUuids)
  console.log(maxNumber, "bbbnnbbn")
  return maxNumber;

}

const counter = (num) => {
  return num + 1
}



const uploadCsv = async (req, res) => {
  try {
    if (req.file == undefined) {
      return res
        .status(400)
        .send({ status: false, message: "Please upload a CSV file!" });
    }
    let path = __basedir + "/uploads/slider/" + req.file.filename;

    fs.createReadStream(path)
      .pipe(csv.parse({ headers: true, columns: true, relax: true }))
      .on("error", (error) => {
        throw error.message;
      })
      .on("data", async (row) => {

        // const newUser=uuid:"STU"+row.country.toUpperCase()+row.state.toUpperCase()+(generateStudentuuid()+1)

        let lastUUID = await generateStudentuuid()
        console.log(lastUUID, "lastUUID");

        let count = counter(lastUUID);
        // let counAndState = row.country + row.state;
        // const uuids = await generateUuidStudent(counAndState);
        let generatedPwd = await generator.generate({
          length: 6,
          numbers: true,
        });


        // const username = row.fname + " " + row.lname;
        // sendMail(row.email, username, generatedPwd, smtpServer, "signup");
        // lastUUID = lastUUID++;
        console.log(lastUUID, "ccccc")
        let document = {
          fname: row.fname,
          lname: row.lname,
          uuid: "STU" + row.country.toUpperCase() + row.state.toUpperCase() + "400000000" + (count),
          password: bcrypt.hashSync(generatedPwd, 8),
          actualPassword: generatedPwd,
          email: row.email,
          gender: (row.gender == "male" ? "1" : "2"),
          dob: row.dob,
          address: row.address,
          mnumber: row.mnumber,
          city: row.city,
          state: row.state,
          pincode: row.pincode,
          country: row.country,
        }
        // console.log(document)
        await User.create(document)

      })
    // res.status(200).send({
    //   message: "created successfully",
    // });

  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Could not upload the file: " + error.message,
    });
  }
};

module.exports = {
  uploadCsv,
};
