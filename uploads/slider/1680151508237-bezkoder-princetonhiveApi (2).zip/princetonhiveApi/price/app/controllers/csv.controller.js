const db = require("../models");
const User = db.user;
const generator = require("generate-password");
const fs = require("fs");
const csv = require("fast-csv");

const generateUUID = require("./uuid.controller");
const generateUuidStudent = require("./uuid.controller");
const { globalConfig, user } = require("../models");
const sendMail = require("./sendmail.controller");
const bcrypt = require("bcryptjs");

const uploadCsv = async (req, res) => {
  try {
    if (req.file == undefined) {
      return res
        .status(400)
        .send({ status: false, message: "Please upload a CSV file!" });
    }

    let users = [];
    const stateandcountery = [];
    let path = __basedir + "/uploads/slider/" + req.file.filename;

    fs.createReadStream(path)
      .pipe(csv.parse({ headers: true, columns: true, relax: true }))
      .on("error", (error) => {
        throw error.message;
      })
      .on("data", async (row) => {
        let counAndState = row.country + row.state;
        stateandcountery.push(counAndState);

        const uuids = await generateUuidStudent(stateandcountery[0]);

        // const smtpServer = await globalConfig.findOne({});

        // if (!smtpServer) {
        //   return res
        //     .status(404)
        //     .send({ success: false, message: "SMTP server not configured!" });
        // }

        let generatedPwd = await generator.generate({
          length: 6,
          numbers: true,
        });
        const username = row.fname + " " + row.lname;
        sendMail(row.email, username, generatedPwd, smtpServer, "signup");
        console.log(JSON.stringify(uuids), "ghhghghg");
        users.push({
          fname: row.fname,
          lname: row.lname,
          uuid: uuids,
          password: bcrypt.hashSync(generatedPwd, 8),
          actualPassword: generatedPwd,
          email: row.email,
          gender: (row.gender = "male" ? "1" : "2"),
          dob: row.dob,
          address: row.address,
          mnumber: row.mnumber,
          city: row.city,
          state: row.state,
          pincode: row.pincode,
          country: row.country,
        });
        // console.log(users, "data");
        // for (let i = 0; i < users.length; i++) {
        //   await User.bulkCreate([users[i]])
        //     .then((response) => {
        //       console.log(response, "responce");
        //     })
        //     .catch((error) => {
        //       return res.status(400).json({
        //         message: "Fail to import data into database!",
        //         error: error.message,
        //       });
        //     });
        // }
        // return res.status(200).json({
        //   message: "Uploaded the file successfully: " + req.file.originalname,
        //   // response,
        // });
      })

      .on("end", async () => {
        console.log(users, "end");
        await User.bulkCreate(users)
          .then((response) => {
            res.status(200).send({
              message:
                "Uploaded the file successfully: " + req.file.originalname,
              response,
            });
            // console.log(response);ls

          })
          .catch((error) => {
            res.status(400).send({
              message: "Fail to import data into database!",
              error: error.message,
            });
          });
      });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Could not upload the file: " + req.file.originalname,
    });
  }
};

module.exports = {
  uploadCsv,
};
