module.exports = {
  secret: "hivesteps-api-secret-key"
};