const db = require("../models");
const User = db.user;
const generateUuidStudent = require("./uuid.controller");
const { globalConfig } = require("../models");
// import { createReadStream } from "fs";
const generator = require("generate-password");
const sendMail = require("./sendmail.controller");
const { createReadStream } = require("fs");
const { parse } = require("fast-csv");
const bcrypt = require("bcryptjs");

const upload = async (req, res) => {
  try {
    if (req.file == undefined) {
      return res.status(400).send("Please upload a CSV file!");
    }

    let users = [];
    const stateandcountery = [];
    let path = __basedir + "/uploads/slider/" + req.file.filename;

    createReadStream(path)
      .pipe(parse({ headers: true }))
      .on("error", (error) => {
        throw error.message;
      })
      .on("data", async (row) => {
        let counAndState = row.country + row.state;
        stateandcountery.push(counAndState);

        const uuids = await generateUuidStudent(stateandcountery[0]);

        const smtpServer = await globalConfig.findOne({});

        if (!smtpServer) {
          return res
            .status(404)
            .send({ success: false, message: "SMTP server not configured!" });
        }

        let generatedPwd = await generator.generate({
          length: 6,
          numbers: true,
        });
        const username = row.fname + " " + row.lname;
        sendMail(row.email, username, generatedPwd, smtpServer, "signup");
        console.log(JSON.stringify(uuids), "ghhghghg");
        // users.push({
        //   fname: row.fname,
        //   lname: row.lname,
        //   uuid: uuids,
        //   password: bcrypt.hashSync(generatedPwd, 8),
        //   actualPassword: generatedPwd,
        //   email: row.email,
        //   gender: (row.gender = "male" ? "1" : "2"),
        //   dob: row.dob,
        //   address: row.address,
        //   mnumber: row.mnumber,
        //   city: row.city,
        //   state: row.state,
        //   pincode: row.pincode,
        //   country: row.country,
        // });
        // for (let i = 0; i < users.length; i++) {
        //   for (let j = i + 1; j < users.length; j++) {
        // if (users[i] != users[j]) {
        await User.bulkCreate([
          {
            fname: row.fname,
            lname: row.lname,
            uuid: uuids,
            password: bcrypt.hashSync(generatedPwd, 8),
            actualPassword: generatedPwd,
            email: row.email,
            gender: (row.gender = "male" ? "1" : "2"),
            dob: row.dob,
            address: row.address,
            mnumber: row.mnumber,
            city: row.city,
            state: row.state,
            pincode: row.pincode,
            country: row.country,
          },
        ])
          .then((response) => {
            res.status(200).send({
              message:
                "The file: " +
                req.file.originalname +
                " got uploaded successfully!!",
              response,
            });
          })
          .catch((error) => {
            res.status(400).send({
              message: "Couldn't import data into database!",
              error: error.message,
            });
          });
        // }
        //   }
        // }
      });
    //   .on("end", () => {
    //     console.log(users, "ends");
    //     User.bulkCreate(users)
    //       .then((response) => {
    //         res.status(200).send({
    //           message:
    //             "The file: " +
    //             req.file.originalname +
    //             " got uploaded successfully!!",
    //           response,
    //         });
    //       })
    //       .catch((error) => {
    //         res.status(500).send({
    //           message: "Couldn't import data into database!",
    //           error: error.message,
    //         });
    //       });
    //   });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Failed to upload the file: " + req.file.originalname,
    });
  }
};

module.exports = {
  upload,
};
