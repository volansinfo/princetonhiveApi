// const a = "TEA";
// let b = 4000000000 + 1;
// console.log(a + b);

const db = require("./app/models");
const User = db.user;

const users = async () => {
  const res = await User.findAll();
  const a = [];
  const tea = [];
  for (let i = 0; i < res.length; i++) {
    const uuids = res[i].uuid;
    a.push(uuids);
    // console.log(res[i].uuid);
  }
  for (let i = 0; i < a.length; i++) {
    const b = a[i].slice(0, 3);
    if (b == "TEA") {
      tea.push(b);
    }
  }

  const total = tea.length;
  console.log(total);
  if (total == 0) {
    const val = 400000000 + 1;
    console.log("STU" + "IN" + "UP" + val);
  } else {
    const mxVal = 400000000 + 10;
    console.log("STU" + "IN" + "UP" + mxVal);
  }
};
users();

let counAndState = row.country + row.state;
stateandcountery.push(counAndState);

const uuids = await generateUuidStudent(stateandcountery[0]);

const smtpServer = await globalConfig.findOne({});

if (!smtpServer) {
  return res
    .status(404)
    .send({ success: false, message: "SMTP server not configured!" });
}

let generatedPwd = await generator.generate({
  length: 6,
  numbers: true,
});
const username = row.fname + " " + row.lname;
sendMail(row.email, username, generatedPwd, smtpServer, "signup");
console.log(JSON.stringify(uuids), "ghhghghg");
await users.push({
  fname: row.fname,
  lname: row.lname,
  uuid: uuids,
  password: bcrypt.hashSync(generatedPwd, 8),
  actualPassword: generatedPwd,
  email: row.email,
  gender: (row.gender = "male" ? "1" : "2"),
  dob: row.dob,
  address: row.address,
  mnumber: row.mnumber,
  city: row.city,
  state: row.state,
  pincode: row.pincode,
  country: row.country,
});
user1.push(row);
console.log(user1, "users");
